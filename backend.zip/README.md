## Gallery fixed
1. Schema
    1. Title
    2. Albam link
    3. Image base64


## Team Fixed
1. Schema
    1. Name
    2. Designation
    3. Image base64
    4. Social Link
        1. Facebook
        2. Linkedin
        3. Instragram
        4. Personal portfolio

## Packages
1. Schema
    1. Title
    2. Inside/Outside
    3. Package image base64
    4. Photographer quantity
    5. Cinematographer qun
    6. Price
    7. Duration
    8. Printed Picture
    9. Video Duration
    10. Trailer Duration
    11. Category

## Booking Package

1. Schema
    1. Bride Name
    2. Groom Name
    3. Event Date & Time
    4. Contact
    5. Venue Details
    6. Package Name
    7. Package Amount
    8. Email ID
    9. Advance Payment
    10. Transaction ID/Number
    11. Account Number
    12. Payment Method

## Testimonial

1. Schema
    1. Name
    2. User Image base64
    3. Text

## Control

### Contact
 1. Schema
    1. Email
    2. Phone
    3. Address

### Banner
1. Schema
    1. Banner Image Title
    2. Image Base64
    3. Image Description

### Logo
1. Schema
    1. Name
    2. logo Base64






#   b a c k e n d  
 